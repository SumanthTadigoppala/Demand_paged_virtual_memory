Commands to use to run the program:
 1) Compile: To compile all files use: make all
 2) Clean: To clean use: make clean
 3) TO run use: ./master k m f
		k = no of processes
		m = no of pages in virtual space
		f = no of frames
    The output will be shown as required and also written to result.txt 